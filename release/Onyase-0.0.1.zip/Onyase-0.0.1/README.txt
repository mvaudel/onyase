

   ===============
    Onyase
   ===============

    This project is currently used to store scripts.

   For updated information about Onyase please visit:
   https://github.com/mvaudel/onyase


   =========
    License
   =========
   
   Copyright Marc Vaudel.


   Licensed under the GPL, Version 3.0;
   you may not use this software except in compliance with the License. 
   See the following link for details.
   
   https://github.com/mvaudel/onyase/blob/master/LICENSE


   Unless required by applicable law or agreed to in writing, software
   distributed under the License is distributed on an "AS IS" BASIS,
   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. 
   See the License for the specific language governing permissions and
   limitations under the License.


   Please note that some of the JAR files used by Onyase may 
   not have the same license as Onyase itself. If you want to use 
   any of these in a different context, make sure to obtain the original 
   license for the JAR file in question.

